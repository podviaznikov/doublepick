Anyone who wishes to use the icons are free to use them. But I have some reservations;

I don' t tolerate using any kind of illegal and bad activity (example; porn, warez, hacking, anti-religion, racism, etc).
Also If that's possible, I just want to see your final work.

Thank you for your interest ...

This work is licensed under a Creative Commons Attribution 3.0 License.
http://creativecommons.org/licenses/by/3.0/



Copyright � cemagraphics
http://cemagraphics.deviantart.com/
cem__ce@hotmail.com